#include<bits/stdc++.h>
using namespace std;

class Mealbazzar
{
public:
    int Meal_number,cost,count,Total_meal,Total_cost,meal1,cost1;
    Mealbazzar()
    {
        count=0;

        cout<<"Enter Your Meal Number: ";
        cin>>Meal_number;
        cout<<"Enter Your Cost: ";
        cin>>cost;
        ofstream fout("meal_file.txt", ios:: app);
        fout<<Meal_number<<" "<<cost<<endl;
        fout.close();

        count++;
        cout<<"\nYou Entered Meal And Cost "<<count<<" times"<<endl;
    }
    void display()
    {
        Total_meal=0;
        Total_cost=0;
        ifstream fin("meal_file.txt", ios::app);

        while(!fin.eof())
        {
            fin>>meal1;
            fin>>cost1;
            Total_meal=Total_meal+meal1;
            Total_cost=Total_cost+cost1;
            meal1=0;
            cost1=0;
        }
        cout<<"Total_meal: "<<Total_meal<<endl;
        cout<<"Total_cost: "<<Total_cost<<endl;
        cout<<"per_meal_cost: "<<(double)Total_cost/Total_meal<<endl;
    }
};

class Mealbazzar1
{
public:
    int Meal_number,cost,count,Total_meal,Total_cost,meal1,cost1;
    Mealbazzar1()
    {
        count=0;

        cout<<"Enter Your Meal Number: ";
        cin>>Meal_number;
        cout<<"Enter Your Cost: ";
        cin>>cost;
        ofstream fout("meal1_file.txt", ios:: app);
        fout<<Meal_number<<" "<<cost<<endl;
        fout.close();

        count++;
        cout<<"\nYou Entered Meal And Cost "<<count<<" times"<<endl;
    }
    void display()
    {
        Total_meal=0;
        Total_cost=0;
        ifstream fin("meal1_file.txt", ios::app);

        while(!fin.eof())
        {
            fin>>meal1;
            fin>>cost1;
            Total_meal=Total_meal+meal1;
            Total_cost=Total_cost+cost1;
            meal1=0;
            cost1=0;
        }
        cout<<"Total_meal: "<<Total_meal<<endl;
        cout<<"Total_cost: "<<Total_cost<<endl;
        cout<<"per_meal_cost: "<<(double)Total_cost/Total_meal<<endl;
    }
};

class Mealbazzar2
{
public:
    int Meal_number,cost,count,Total_meal,Total_cost,meal1,cost1;
    Mealbazzar2()
    {
        count=0;

        cout<<"Enter Your Meal Number: ";
        cin>>Meal_number;
        cout<<"Enter Your Cost: ";
        cin>>cost;
        ofstream fout("meal2_file.txt", ios:: app);
        fout<<Meal_number<<" "<<cost<<endl;
        fout.close();

        count++;
        cout<<"\nYou Entered Meal And Cost "<<count<<" times"<<endl;
    }
    void display()
    {
        Total_meal=0;
        Total_cost=0;
        ifstream fin("meal2_file.txt", ios::app);

        while(!fin.eof())
        {
            fin>>meal1;
            fin>>cost1;
            Total_meal=Total_meal+meal1;
            Total_cost=Total_cost+cost1;
            meal1=0;
            cost1=0;
        }
        cout<<"Total_meal: "<<Total_meal<<endl;
        cout<<"Total_cost: "<<Total_cost<<endl;
        cout<<"per_meal_cost: "<<(double)Total_cost/Total_meal<<endl;
    }
};

class Mealbazzar3
{
public:
    int Meal_number,cost,count,Total_meal,Total_cost,meal1,cost1;
    Mealbazzar3()
    {
        count=0;

        cout<<"Enter Your Meal Number: ";
        cin>>Meal_number;
        cout<<"Enter Your Cost: ";
        cin>>cost;
        ofstream fout("meal3_file.txt", ios:: app);
        fout<<Meal_number<<" "<<cost<<endl;
        fout.close();

        count++;
        cout<<"\nYou Entered Meal And Cost "<<count<<" times"<<endl;
    }
    void display()
    {
        Total_meal=0;
        Total_cost=0;
        ifstream fin("meal3_file.txt", ios::app);

        while(!fin.eof())
        {
            fin>>meal1;
            fin>>cost1;
            Total_meal=Total_meal+meal1;
            Total_cost=Total_cost+cost1;
            meal1=0;
            cost1=0;
        }
        cout<<"Total_meal: "<<Total_meal<<endl;
        cout<<"Total_cost: "<<Total_cost<<endl;
        cout<<"per_meal_cost: "<<(double)Total_cost/Total_meal<<endl;
    }
};


class Sohel
{
public:
    void address_display()
    {
        char name[20];
        begin:
            cout<<"\nRe-type Your User Name: ";
            cin>>name;
            if(strcmp(name,"Sohel")==0)
            {
                cout<<"\n\nName: "<<name<<endl;
                cout<<"Occuption: Student\n";
                cout<<"Phone Number: 01780694475\n";
                cout<<"Home dist: Thakurgaon\n"<<endl;
            }
            else{
                cout<<"\nNo Name Available\n"<<endl;
                goto begin;
            }

    }
};

class Abir
{
public:
    void address_display()
    {
        char name[20];
        begin:
            cout<<"\nRe-type Your User Name: ";
            cin>>name;
            if(strcmp(name,"Abir")==0)
            {
                cout<<"\n\nName: "<<name<<endl;
                cout<<"Occuption: Student\n";
                cout<<"Phone Number: 01914567869\n";
                cout<<"Home dist: Panchagarh\n"<<endl;
            }
            else{
                cout<<"\nNo Name Available\n"<<endl;
                goto begin;
            }

    }
};

class Taki
{
public:
    void address_display()
    {
        char name[20];
        begin:
            cout<<"\nRe-type Your User Name: ";
            cin>>name;
            if(strcmp(name,"Taki")==0)
            {
                cout<<"\n\nName: "<<name<<endl;
                cout<<"Occuption: Student\n";
                cout<<"Phone Number: 01876353645\n";
                cout<<"Home dist: Dinajpur\n"<<endl;
            }
            else{
                cout<<"\nNo Name Available\n"<<endl;
                goto begin;
            }

    }
};

class Sumon
{
public:
    void address_display()
    {
        char name[20];
        begin:
            cout<<"\nRe-type Your User Name: ";
            cin>>name;
            if(strcmp(name,"Sumon")==0)
            {
                cout<<"\n\nName: "<<name<<endl;
                cout<<"Occuption: Student\n";
                cout<<"Phone Number: 01654263457\n";
                cout<<"Home dist: Nilphamari\n"<<endl;
            }
            else{
                cout<<"\nNo Name Available\n"<<endl;
                goto begin;
            }

    }
};


int main()
{
    int user_number;
    cout<<"\n\n\t\t\tBismillah Mess Management System"<<endl;
    cout<<"\t\t\t................................"<<endl;

    do
    {
        cout<<"\n\nMess Border Name List: "<<endl;
        cout<<"\n1.Sohel\n2.Abir\n3.Taki\n4.Sumon"<<endl;
        cout<<"\n\nInput User Number: ";
        cin>>user_number;

        switch(user_number)
        {
        case 1:
        {
                Sohel sohel;
                sohel.address_display();

                Mealbazzar obj;
                obj.display();
                break;
        }

        case 2:
        {
                Abir abir;
                abir.address_display();

                Mealbazzar1 obj;
                obj.display();
                break;
        }

        case 3:
        {
                Taki taki;
                taki.address_display();

                Mealbazzar obj;
                obj.display();
                break;
        }

        case 4:
        {
                Sumon sumon;
                sumon.address_display();

                Mealbazzar obj;
                obj.display();
                break;
        }

        default:

            cout<<"\nUser Number No Available"<<endl;
        }
    }
    while(1);

    return 0;
}
